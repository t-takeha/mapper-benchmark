package com.javaetmoi.benchmark.mapping.mapper.beanutils;

import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.BeanUtils;

import com.javaetmoi.benchmark.mapping.mapper.OrderMapper;
import com.javaetmoi.benchmark.mapping.model.dto.OrderDTO;
import com.javaetmoi.benchmark.mapping.model.entity.Order;

public class BeanUtilsMapper implements OrderMapper {

    public BeanUtilsMapper() {}

    @Override
    public OrderDTO map(Order source) {
    	OrderDTO dst = new OrderDTO();

    	try {
			BeanUtils.copyProperties(dst, source);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}
        return dst;
    }
}
